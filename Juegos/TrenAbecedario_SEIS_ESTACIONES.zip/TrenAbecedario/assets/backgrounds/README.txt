Carpeta para recursos personalizados.
